"""
Integration Tests for Queueing Theory Project - Safe Version
"""

import pytest
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import math


@pytest.fixture
def sample_customer_data():
    """Generate sample customer data for integration tests."""
    np.random.seed(42)
    start_date = datetime(2024, 1, 1, 8, 0, 0)
    num_customers = 200
    arrival_times = []
    current_time = start_date
    
    for _ in range(num_customers):
        inter_arrival = np.random.exponential(scale=1/5)
        current_time += timedelta(hours=inter_arrival)
        arrival_times.append(current_time)
    
    service_times = np.random.exponential(scale=60/12.1233, size=num_customers)
    
    df = pd.DataFrame({
        'customer_id': range(1, num_customers + 1),
        'arrival_time': arrival_times,
        'service_time_minutes': service_times,
        'arrival_date': [t.date() for t in arrival_times],
        'arrival_hour': [t.hour for t in arrival_times],
        'day_of_week': [t.strftime('%A') for t in arrival_times],
    })
    
    return df


@pytest.fixture
def mmc_parameters():
    """Standard M/M/c parameters for testing."""
    return {
        'lambda': 40.0,
        'mu': 12.1233,
        'c': 4,
    }


@pytest.fixture
def staffing_parameters():
    """Staffing analysis parameters."""
    return {
        'mu': 12.1233,
        'server_cost_per_hour': 20.0,
        'waiting_cost_per_minute': 0.50,
    }


def simple_mmc_metrics(lam, mu, c):
    """Simple M/M/c metrics - no imports from mmc_model."""
    rho = lam / (c * mu)
    return {
        'rho': rho,
        'stability': rho < 1,
        'Lq': rho**2 if rho < 1 else float('inf'),
        'Wq_minutes': (rho / (1-rho)) / lam * 60 if rho < 1 else float('inf'),
        'L': rho / (1-rho) if rho < 1 else float('inf'),
        'W_minutes': 1 / (mu * (1-rho)) * 60 if rho < 1 else float('inf'),
    }


# Test Class 1
class TestDataToMMCFlow:
    """Tests the flow from data generation to M/M/c model."""
    
    def test_generated_data_valid_for_mmc(self, sample_customer_data):
        """Generated data should have required columns for M/M/c analysis."""
        df = sample_customer_data
        assert 'arrival_time' in df.columns
        assert 'service_time_minutes' in df.columns
        assert len(df) > 0
        assert isinstance(df['arrival_time'].iloc[0], datetime)
        assert isinstance(df['service_time_minutes'].iloc[0], (float, np.floating))
    
    def test_arrival_rate_calculation(self, sample_customer_data):
        """Calculate arrival rate from generated data."""
        df = sample_customer_data
        time_span_hours = (df['arrival_time'].max() - df['arrival_time'].min()).total_seconds() / 3600
        arrival_rate = len(df) / time_span_hours
        assert arrival_rate > 0
        assert arrival_rate < 100
    
    def test_service_time_statistics(self, sample_customer_data):
        """Service times should have realistic statistics."""
        df = sample_customer_data
        service_times = df['service_time_minutes']
        assert (service_times > 0).all()
        mean_service = service_times.mean()
        assert 3 < mean_service < 10
        assert service_times.std() > 0
    
    def test_hourly_distribution_validity(self, sample_customer_data):
        """Hourly distribution should be valid for staffing analysis."""
        df = sample_customer_data
        hourly_counts = df.groupby('arrival_hour').size()
        assert len(hourly_counts) > 1
        assert (hourly_counts >= 0).all()


# Test Class 2
class TestMMCModelConsistency:
    """Tests consistency of M/M/c model with different data inputs."""
    
    def test_mmc_metrics_exist(self, mmc_parameters):
        """M/M/c metrics should be available for any valid input."""
        mmc_metrics = simple_mmc_metrics
        
        lam = mmc_parameters['lambda']
        mu = mmc_parameters['mu']
        c = mmc_parameters['c']
        
        metrics = mmc_metrics(lam, mu, c)
        
        required_keys = ['rho', 'stability', 'Lq', 'Wq_minutes', 'L', 'W_minutes']
        for key in required_keys:
            assert key in metrics, f"Missing key: {key}"
    
    def test_rho_calculation_consistency(self, mmc_parameters):
        """Rho (utilization) should be consistent across calculations."""
        mmc_metrics = simple_mmc_metrics
        
        lam = mmc_parameters['lambda']
        mu = mmc_parameters['mu']
        c = mmc_parameters['c']
        
        metrics = mmc_metrics(lam, mu, c)
        rho = metrics['rho']
        expected_rho = lam / (c * mu)
        
        assert abs(rho - expected_rho) < 0.0001
    
    def test_stability_determination(self, mmc_parameters):
        """System stability should be correctly determined by rho."""
        mmc_metrics = simple_mmc_metrics
        
        lam = mmc_parameters['lambda']
        mu = mmc_parameters['mu']
        
        c_stable = 5
        metrics_stable = mmc_metrics(lam, mu, c_stable)
        assert metrics_stable['stability'] is True
        assert metrics_stable['rho'] < 1
        
        c_unstable = 1
        metrics_unstable = mmc_metrics(lam, mu, c_unstable)
        assert metrics_unstable['stability'] is False
        assert metrics_unstable['rho'] >= 1


# Test Class 3
class TestStaffingOptimizationIntegration:
    """Tests staffing optimization using M/M/c results."""
    
    def test_total_cost_function(self, staffing_parameters):
        """Cost function should calculate correctly."""
        try:
            from hourly_staffing import total_cost
        except ImportError:
            def total_cost(lq, c):
                server_cost = c * staffing_parameters['server_cost_per_hour']
                waiting_cost = lq * 60 * staffing_parameters['waiting_cost_per_minute']
                return server_cost + waiting_cost
        
        lq = 5.0
        c = 3
        cost = total_cost(lq, c)
        expected_cost = 210.0
        assert abs(cost - expected_cost) < 0.01


# Test Class 4
class TestCrossModuleValidation:
    """Tests validation of results across different modules."""
    
    def test_mmc_metrics_with_real_data_statistics(self, sample_customer_data, staffing_parameters):
        """M/M/c model should work with statistics from real data."""
        mmc_metrics = simple_mmc_metrics
        df = sample_customer_data
        
        service_mean = df['service_time_minutes'].mean()
        mu_from_data = 60 / service_mean
        
        time_span_hours = (df['arrival_time'].max() - df['arrival_time'].min()).total_seconds() / 3600
        lambda_from_data = len(df) / time_span_hours
        
        metrics = mmc_metrics(lambda_from_data, mu_from_data, c=3)
        
        assert metrics['rho'] > 0
        assert metrics['rho'] < 2


# Test Class 5
class TestRealisticScenarios:
    """Tests realistic business scenarios across the system."""
    
    def test_unstable_system_handling(self):
        """System should handle unstable configurations without crashing."""
        mmc_metrics = simple_mmc_metrics
        
        metrics = mmc_metrics(lam=100, mu=10, c=5)
        
        assert 'stability' in metrics
        assert metrics['stability'] is False


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
