"""
test_data_generation.py

Tests para data_generation.py
Coloca este archivo en: tests/test_data_generation.py
"""

import pytest
import numpy as np
import pandas as pd
from pathlib import Path
import tempfile
import shutil
from sys import path

# Agregamos el directorio del módulo al path
proyecto_root = Path(__file__).parent.parent
path.insert(0, str(proyecto_root / "01_Data_generation"))


# ============================================================
# FIXTURES
# ============================================================

@pytest.fixture
def temp_data_dir():
    """Crea un directorio temporal para los datos."""
    temp_dir = tempfile.mkdtemp()
    yield temp_dir
    # Limpia después del test
    shutil.rmtree(temp_dir, ignore_errors=True)


@pytest.fixture
def sample_dataframe():
    """Genera un DataFrame de ejemplo similar al que produce data_generation."""
    np.random.seed(42)

    customers = []
    customer_id = 1
    start_date = pd.Timestamp("2026-01-01")

    # Generar datos más pequeños para tests (3 días en lugar de 30)
    for day in range(3):
        current_date = start_date + pd.Timedelta(days=day)

        for hour in [8, 12, 16]:  # Solo algunas horas
            arrival_rate = {8: 20, 12: 65, 16: 30}[hour]
            number_of_customers = np.random.poisson(arrival_rate)

            arrival_minutes = np.random.uniform(0, 60, number_of_customers)

            for minute in arrival_minutes:
                arrival_time = (
                    current_date
                    + pd.Timedelta(hours=hour)
                    + pd.Timedelta(minutes=float(minute))
                )

                service_time = np.random.exponential(scale=5)

                customers.append({
                    "customer_id": customer_id,
                    "arrival_time": arrival_time,
                    "service_time_min": service_time,
                    "hour": hour,
                    "day_of_week": current_date.day_name()
                })

                customer_id += 1

    df = pd.DataFrame(customers)
    # IMPORTANTE: Después de ordenar, debemos resetear los IDs
    df = df.sort_values("arrival_time").reset_index(drop=True)
    # Regenerar customer_id secuencialmente después de ordenar
    df['customer_id'] = range(1, len(df) + 1)
    # Convertir day_of_week a object type (string)
    df['day_of_week'] = df['day_of_week'].astype(object)

    return df


# ============================================================
# 1. TESTS DE ESTRUCTURA DEL DATAFRAME
# ============================================================

class TestDataFrameStructure:
    """Tests para validar la estructura del DataFrame generado."""

    def test_dataframe_has_required_columns(self, sample_dataframe):
        """El DataFrame contiene todas las columnas requeridas."""
        required_cols = [
            'customer_id',
            'arrival_time',
            'service_time_min',
            'hour',
            'day_of_week'
        ]

        for col in required_cols:
            assert col in sample_dataframe.columns

    def test_dataframe_not_empty(self, sample_dataframe):
        """El DataFrame contiene datos."""
        assert len(sample_dataframe) > 0

    def test_all_rows_have_data(self, sample_dataframe):
        """No hay valores NaN en los datos."""
        assert sample_dataframe.isna().sum().sum() == 0

    def test_correct_column_count(self, sample_dataframe):
        """El DataFrame tiene exactamente 5 columnas."""
        assert len(sample_dataframe.columns) == 5


# ============================================================
# 2. TESTS DE TIPOS DE DATOS
# ============================================================

class TestDataTypes:
    """Tests para validar tipos de datos en cada columna."""

    def test_customer_id_is_integer(self, sample_dataframe):
        """customer_id es de tipo entero."""
        assert sample_dataframe['customer_id'].dtype in [np.int64, np.int32, int]

    def test_arrival_time_is_datetime(self, sample_dataframe):
        """arrival_time es de tipo datetime."""
        assert pd.api.types.is_datetime64_any_dtype(sample_dataframe['arrival_time'])

    def test_service_time_is_numeric(self, sample_dataframe):
        """service_time_min es numérico."""
        assert pd.api.types.is_numeric_dtype(sample_dataframe['service_time_min'])

    def test_hour_is_integer(self, sample_dataframe):
        """hour es de tipo entero."""
        assert sample_dataframe['hour'].dtype in [np.int64, np.int32, int]

    def test_day_of_week_is_string_like(self, sample_dataframe):
        """day_of_week es de tipo string (object o StringDtype)."""
        dtype_str = str(sample_dataframe['day_of_week'].dtype)
        assert 'str' in dtype_str.lower() or 'string' in dtype_str.lower() or sample_dataframe['day_of_week'].dtype == object


# ============================================================
# 3. TESTS DE VALORES Y RANGOS
# ============================================================

class TestValueRanges:
    """Tests para validar rangos de valores."""

    def test_customer_ids_unique(self, sample_dataframe):
        """Todos los customer_id son únicos."""
        assert sample_dataframe['customer_id'].is_unique

    def test_customer_ids_sequential(self, sample_dataframe):
        """Los customer_id son secuenciales."""
        expected_ids = list(range(1, len(sample_dataframe) + 1))
        actual_ids = sample_dataframe['customer_id'].tolist()
        assert actual_ids == expected_ids

    def test_service_time_positive(self, sample_dataframe):
        """Todos los tiempos de servicio son positivos."""
        assert (sample_dataframe['service_time_min'] > 0).all()

    def test_service_time_reasonable(self, sample_dataframe):
        """Los tiempos de servicio están en un rango razonable (0.1 a 100 minutos)."""
        assert (sample_dataframe['service_time_min'] >= 0.01).all()
        assert (sample_dataframe['service_time_min'] <= 500).all()

    def test_hour_in_valid_range(self, sample_dataframe):
        """Las horas están en el rango válido (8-16)."""
        assert sample_dataframe['hour'].min() >= 8
        assert sample_dataframe['hour'].max() <= 16

    def test_hour_values_match_arrival_rates(self, sample_dataframe):
        """Las horas presentes son las definidas en ARRIVAL_RATES."""
        valid_hours = {8, 9, 10, 11, 12, 13, 14, 15, 16}
        actual_hours = set(sample_dataframe['hour'].unique())
        assert actual_hours.issubset(valid_hours)


# ============================================================
# 4. TESTS DE FECHAS Y TIEMPOS
# ============================================================

class TestDatesAndTimes:
    """Tests para validar consistencia de fechas y tiempos."""

    def test_arrival_times_ordered(self, sample_dataframe):
        """Los arrival_time están ordenados de menor a mayor."""
        times = sample_dataframe['arrival_time'].values
        assert (times == np.sort(times)).all()

    def test_arrival_times_within_operating_hours(self, sample_dataframe):
        """Los tiempos de llegada están dentro del horario de operación (8:00-17:00)."""
        sample_dataframe['arrival_hour'] = sample_dataframe['arrival_time'].dt.hour

        # Incluir hora 17 porque si alguien llega a las 17:59 está dentro del día
        assert sample_dataframe['arrival_hour'].min() >= 8
        assert sample_dataframe['arrival_hour'].max() <= 17

    def test_day_of_week_is_valid(self, sample_dataframe):
        """Los day_of_week contienen valores válidos."""
        valid_days = {
            'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday',
            'Saturday', 'Sunday'
        }
        actual_days = set(sample_dataframe['day_of_week'].unique())
        assert actual_days.issubset(valid_days)

    def test_day_of_week_matches_arrival_time(self, sample_dataframe):
        """El day_of_week coincide con el día real en arrival_time."""
        sample_dataframe['computed_day'] = (
            sample_dataframe['arrival_time'].dt.day_name()
        )

        match = sample_dataframe['day_of_week'] == sample_dataframe['computed_day']
        assert match.all()


# ============================================================
# 5. TESTS DE ESTADÍSTICAS
# ============================================================

class TestStatistics:
    """Tests para validar estadísticas descriptivas."""

    def test_service_time_has_positive_mean(self, sample_dataframe):
        """El tiempo promedio de servicio es positivo."""
        mean_service = sample_dataframe['service_time_min'].mean()
        assert mean_service > 0

    def test_service_time_has_positive_std(self, sample_dataframe):
        """La desviación estándar del servicio es positiva."""
        std_service = sample_dataframe['service_time_min'].std()
        assert std_service > 0

    def test_service_time_mean_close_to_expected(self, sample_dataframe):
        """La media del servicio es cercana a 5 minutos (MEAN_SERVICE_TIME)."""
        # Para distribución exponencial, la media es el scale
        # Permitimos variación por aleatoriedad
        mean_service = sample_dataframe['service_time_min'].mean()
        assert 2 < mean_service < 10  # Rango razonable

    def test_customers_per_hour_reasonable(self, sample_dataframe):
        """El número de clientes por hora es razonable."""
        customers_per_hour = sample_dataframe.groupby('hour').size()

        # Debe haber algún dato
        assert len(customers_per_hour) > 0

        # No debe haber horas sin clientes
        assert (customers_per_hour > 0).all()


# ============================================================
# 6. TESTS DE CONSISTENCIA
# ============================================================

class TestConsistency:
    """Tests para validar consistencia de los datos."""

    def test_no_duplicate_rows(self, sample_dataframe):
        """No hay filas duplicadas exactas."""
        assert sample_dataframe.duplicated().sum() == 0

    def test_arrival_time_hour_matches_hour_column(self, sample_dataframe):
        """La hora en arrival_time coincide con la columna hour."""
        sample_dataframe['computed_hour'] = (
            sample_dataframe['arrival_time'].dt.hour
        )

        match = sample_dataframe['hour'] == sample_dataframe['computed_hour']
        assert match.all()

    def test_customer_id_starts_at_one(self, sample_dataframe):
        """El primer customer_id es 1."""
        assert sample_dataframe['customer_id'].iloc[0] == 1

    def test_customer_id_increments_by_one(self, sample_dataframe):
        """Los customer_id incrementan de 1 en 1."""
        diffs = sample_dataframe['customer_id'].diff().fillna(1)
        assert (diffs == 1).all()


# ============================================================
# 7. TESTS DE CANTIDAD DE DATOS
# ============================================================

class TestDataVolume:
    """Tests para validar volumen de datos."""

    def test_reasonable_customer_count(self, sample_dataframe):
        """La cantidad de clientes es razonable."""
        # Para 3 días con tasas entre 20-65 clientes/hora
        # y 3 horas por día, esperamos al menos 100 clientes
        assert len(sample_dataframe) > 50

    def test_all_hours_represented(self, sample_dataframe):
        """Las horas presentes tienen al menos algunos clientes."""
        hours = sample_dataframe['hour'].unique()
        assert len(hours) > 0


# ============================================================
# 8. TESTS DE DISTRIBUCIONES
# ============================================================

class TestDistributions:
    """Tests para validar que las distribuciones son razonables."""

    def test_service_time_distribution_shape(self, sample_dataframe):
        """La distribución de tiempos de servicio es razonable."""
        service_times = sample_dataframe['service_time_min']

        # Para exponencial, esperamos que la mayoría esté cerca de la media
        # y algunos valores altos
        mean = service_times.mean()
        std = service_times.std()

        # La desviación estándar debería ser cercana a la media
        # (propiedad de exponencial)
        assert 0.5 * mean < std < 2 * mean

    def test_arrival_distribution_per_hour(self, sample_dataframe):
        """La distribución de llegadas por hora sigue una tendencia."""
        arrivals_by_hour = sample_dataframe.groupby('hour').size()

        # Debe haber variación entre horas
        assert arrivals_by_hour.std() > 0


# ============================================================
# 9. TESTS DE CASOS ESPECIALES
# ============================================================

class TestEdgeCases:
    """Tests para casos especiales."""

    def test_minimum_one_customer_per_day(self, sample_dataframe):
        """Hay al menos un cliente por día (estadísticamente probable)."""
        customers_per_day = (
            sample_dataframe.groupby(sample_dataframe['arrival_time'].dt.date).size()
        )

        assert len(customers_per_day) > 0

    def test_no_future_dates(self, sample_dataframe):
        """Todas las fechas están en el rango esperado (enero 2026)."""
        min_date = sample_dataframe['arrival_time'].min()
        max_date = sample_dataframe['arrival_time'].max()

        assert min_date.year == 2026
        assert min_date.month == 1
        assert max_date.year == 2026


# ============================================================
# 10. TESTS DE INTEGRACIÓN
# ============================================================

class TestIntegration:
    """Tests para validar integración de datos."""

    def test_dataframe_can_be_saved_to_csv(self, sample_dataframe, temp_data_dir):
        """El DataFrame puede guardarse como CSV."""
        csv_path = Path(temp_data_dir) / "test.csv"
        sample_dataframe.to_csv(csv_path, index=False)

        assert csv_path.exists()
        assert csv_path.stat().st_size > 0

    def test_saved_csv_can_be_loaded(self, sample_dataframe, temp_data_dir):
        """Un CSV guardado puede recargarse correctamente."""
        csv_path = Path(temp_data_dir) / "test.csv"
        sample_dataframe.to_csv(csv_path, index=False)

        loaded_df = pd.read_csv(csv_path)

        # Las columnas deben coincidir
        assert list(loaded_df.columns) == list(sample_dataframe.columns)

        # Las filas deben coincidir
        assert len(loaded_df) == len(sample_dataframe)

    def test_csv_preserves_numeric_data(self, sample_dataframe, temp_data_dir):
        """El CSV preserva los datos numéricos correctamente."""
        csv_path = Path(temp_data_dir) / "test.csv"
        sample_dataframe.to_csv(csv_path, index=False)

        loaded_df = pd.read_csv(csv_path)

        # Los customer_id deben ser enteros (aunque se carguen como float)
        assert (loaded_df['customer_id'] == sample_dataframe['customer_id'].values).all()

    def test_groupby_operations_work(self, sample_dataframe):
        """Las operaciones de groupby funcionan correctamente."""
        # Por hora
        by_hour = sample_dataframe.groupby('hour').size()
        assert len(by_hour) > 0

        # Por día de la semana
        by_day = sample_dataframe.groupby('day_of_week').size()
        assert len(by_day) > 0

    def test_sorting_by_arrival_time_maintains_order(self, sample_dataframe):
        """Ordenar por arrival_time mantiene el orden."""
        sorted_df = sample_dataframe.sort_values('arrival_time')

        times = sorted_df['arrival_time'].values
        assert (times == np.sort(times)).all()


# ============================================================
# 11. TESTS DE REPRODUCIBILIDAD
# ============================================================

class TestReproducibility:
    """Tests para validar reproducibilidad con seed."""

    def test_same_seed_produces_same_results(self):
        """El mismo seed produce los mismos datos."""
        # Primera ejecución
        np.random.seed(42)
        data1 = np.random.poisson(50, 100)

        # Segunda ejecución con el mismo seed
        np.random.seed(42)
        data2 = np.random.poisson(50, 100)

        assert (data1 == data2).all()

    def test_different_seeds_produce_different_results(self):
        """Seeds diferentes producen datos diferentes."""
        np.random.seed(42)
        data1 = np.random.poisson(50, 100)

        np.random.seed(123)
        data2 = np.random.poisson(50, 100)

        assert (data1 != data2).any()


# ============================================================
# 12. TESTS DE ERRORES Y VALIDACIONES
# ============================================================

class TestErrorHandling:
    """Tests para manejo de errores y validaciones."""

    def test_empty_dataframe_has_correct_structure(self):
        """Un DataFrame vacío tiene la estructura correcta."""
        empty_df = pd.DataFrame({
            'customer_id': [],
            'arrival_time': [],
            'service_time_min': [],
            'hour': [],
            'day_of_week': []
        })

        assert list(empty_df.columns) == [
            'customer_id', 'arrival_time', 'service_time_min', 'hour', 'day_of_week'
        ]

    def test_negative_service_time_would_be_invalid(self):
        """Tiempos negativos serían inválidos (no deben ocurrir)."""
        # Verificar que np.random.exponential nunca produce negativos
        samples = np.random.exponential(scale=5, size=10000)
        assert (samples >= 0).all()


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
